<html>
<head>
        <style type="text/css">
            body{
                font-family: 'Segoe UI',sans-serif;
            }
            h3{
                text-shadow: 0 3px 5px 0 rgba(0,0,0,0.2);
            }
            .button {
                background-color: #4CAF50; /* Green */
                border: none;
                color: white;
                padding: 5px 20px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin: 4px 2px;
                cursor: pointer;
                -webkit-transition-duration: 0.4s; /* Safari */
                 transition-duration: 0.4s;
            }
            .button1 {
                 box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
            }
            }
            table, th, td {
                border: 1px solid white;
                border-collapse: collapse;
            }
            th, td {
            background-color: #4CAF50;
            }
            table.center {
                margin-left: auto; 
                margin-right: auto;
            }
        </style>
    </head>
<body>
    
<h3 style="text-align:center;">Form Details</h3>
<form style="text-align:center;" action="try1.php" method="post" enctype="multipart/form-data">
<label class="control-label col-sm-2">First Name</label><br><input type="text" name="firstname" required="" value="">
<br>
<label class="control-label col-sm-2">Last Name</label><br><input type="text" name="lastname" required="" value="">
<br>
<label class="control-label col-sm-2">Email</label><br><input type="email" name="email" value="" required="">
<br><br>
Experience: 
        <select id="Experience" name="experience">  
            <option value="1"> 1 </option>
            <option value="2"> 2 </option>
            <option value="3"> 3 </option>
            <option value="4"> 4 </option>
            <option value="4"> 4 </option>
        </select><br></br>
        <input type="file" name="file" ><br><br>       
<!-- <input type="submit" name="submit"   value="CSV File"> -->
        <button class="button button1">CSV File</button>

<?php
if(key_exists('file',$_FILES)){
    $tmp_name=$_FILES["file"]["tmp_name"];
    $file_name=$_FILES["file"]["name"];
    $dir= getcwd().'/'.$file_name;

    $firstName=$_POST["firstname"];
    $lastName=$_POST["lastname"];
    $email=$_POST["email"];
    $experience=$_POST["experience"];

    $content= $firstName."\n" .$lastName."\n" .$email."\n" .$experience;
    if(move_uploaded_file($tmp_name,$dir)){
        echo "File Uploaded...! <br><br>";
    } else {
        echo "File not Uploaded <br><br>";
    }

    $myfile=fopen("data.csv","a+");
    $form_data= array(
        'firstname' => $firstName,
        'lastname' => $lastName,
        'email' => $email,
        'Experience' => $experience
    );
    fputcsv($myfile, $form_data);
    fclose($myfile);

    $myfile=fopen("data.csv","r");
    $row= 1;
    echo "Submitted Details";
    echo "
    <table class='center'>
        <tr>
            <th>First name</th>
            <th>Last name</th>
            <th>Email</th>
            <th>Experience</th>
        </tr>
    ";

    while(($data=fgetcsv($myfile,1000,",")) !== FALSE){
        $num=count($data);
        echo "<tr>";

        $row++;
        for($i=0;$i<$num;$i++){
            echo "<td>$data[$i]</td>";

        }
        echo "</tr>";
    }
    echo "</table>";
    fclose($myfile);
}
?>
</form>
</body>
</html>

